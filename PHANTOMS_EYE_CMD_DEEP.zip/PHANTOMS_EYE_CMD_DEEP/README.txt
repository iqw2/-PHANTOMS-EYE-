PHANTOMS EYE // CMD EDITION v2.3
=================================

Run on Windows:
  - Extract the ZIP
  - Double-click START_PHANTOMS_EYE.bat
  - Or run: python phantoms_eye_cmd.py

Modules:
1 IP Deep Search
2 URL Deep Search
3 DNS Lookup
4 Hash Analyzer
5 Base64 / Text
6 JSON Inspector
7 Log Analyzer
8 Email Header Check
9 Localhost Port Check (127.0.0.1 only)
10 About / Help

The URL and IP reports include public DNS/PTR information, public geolocation/network
metadata when available, RDAP registry records, and for URLs HTTP response headers,
security-header checks and TLS certificate details. Registry/API data varies and may
be unavailable. Geo-IP results are approximate.

No third-party packages are required. Internet access is needed for online lookups.
Use only for lawful defensive analysis. No exploitation, malware execution, credential
theft, flooding, or remote port scanning is included.
