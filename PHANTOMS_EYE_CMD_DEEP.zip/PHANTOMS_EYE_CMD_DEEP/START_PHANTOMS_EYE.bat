@echo off
cd /d "%~dp0"
python phantoms_eye_cmd.py
if errorlevel 1 pause
