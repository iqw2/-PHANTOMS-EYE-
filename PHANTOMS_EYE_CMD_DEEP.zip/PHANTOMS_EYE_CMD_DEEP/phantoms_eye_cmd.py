# -*- coding: utf-8 -*-
"""PHANTOMS EYE // CMD EDITION - detailed passive lookup reports."""
import os, sys, socket, ssl, ipaddress, urllib.request, urllib.parse, json, hashlib, base64, re
from datetime import datetime

PURPLE = "\033[95m"
BLUE = "\033[94m"
WHITE = "\033[97m"
DIM = "\033[90m"
RESET = "\033[0m"
BOLD = "\033[1m"
WIDTH = 78

# Box-framed ASCII eye inspired by the user's screenshot (original drawing).
EYE = r"""
+--------------------------------------------------------------------------+
|                                                                          |
|                         .:--====--:.                                     |
|                    .-+*############*+-.                                  |
|                 .-*####################*-.                               |
|               :*##########################*:                             |
|             :*########*+=--::::--=+*########*:                           |
|           .*######*=-.                .-=*######*.                       |
|          +#####*-.       .:--------:.      .-*#####*+                     |
|        .*####+:      .-+*############*+-.     :+####*.                    |
|       :####*:     .+####################+.     :*####:                    |
|      :####+     .*########################*.    +####:                    |
|     .####=     +########*=-::::-=*#########+    =####.                    |
|     +####.    *########+.          .+########*   .####+                   |
|    :####:   .########+     .----.    +########.   :####:                  |
|    +####   .########=    .+######+.   =########.  ####+                   |
|    ####+   *#######*    :##########:   *#######*  +####                   |
|    ####.  :#######*    .############.  *#######:  .####                   |
|    ####.  *#######=     *##########*   =#######*  .####                   |
|    ####+  *#######=     *##########*   =#######*  +####                   |
|    +####  :#######*    .############.  *#######:  ####+                   |
|    :####:  *#######*    :##########:   *#######* :####:                   |
|     +####.  +########=   .+######+.  =########+ .####+                    |
|      .####=   +########+.   '----'  .+########+ =####.                    |
|       :####+   .*########+.       .+########*. +####:                     |
|        :####*:    +######################+   :*####:                      |
|          .*####+:    .+################+.  :+####*.                       |
|            +#####*-.    .:--======--:.  .-*#####*+                         |
|              .*######*=-.          .-=*######*.                           |
|                :*########*+=--::--=+*########*:                           |
|                  .-*####################*-.                               |
|                     .-+*############*+-.                                  |
|                                                                          |
+--------------------------------------------------------------------------+
"""

TOOLS = [
    ("IP DEEP SEARCH", "Public IP metadata, PTR, geolocation, ASN and RDAP"),
    ("URL DEEP SEARCH", "DNS, HTTP, redirects, security headers, TLS and IP metadata"),
    ("DNS LOOKUP", "Resolve hostname to IPv4/IPv6 addresses"),
    ("HASH ANALYZER", "SHA-256 / SHA-1 / MD5 for local files"),
    ("BASE64 / TEXT", "Encode or decode text"),
    ("JSON INSPECTOR", "Validate and pretty-print JSON"),
    ("LOG ANALYZER", "Find common error and warning indicators"),
    ("EMAIL HEADER CHECK", "Review common email header fields"),
    ("LOCALHOST PORT CHECK", "Check selected ports on 127.0.0.1 only"),
    ("ABOUT / HELP", "Usage and safety notes"),
]

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def rule(char="=", width=WIDTH):
    print(PURPLE + char * width + RESET)

def pause():
    input(f"\n{DIM}Press Enter to return to menu...{RESET}")

def ask(prompt):
    return input(PURPLE + prompt + RESET).strip()

def header(title):
    clear()
    print(PURPLE + BOLD + f"PHANTOMS EYE // {title}" + RESET)
    rule()

def print_json_block(label, value):
    print(f"\n[{label}]")
    print(json.dumps(value, indent=2, ensure_ascii=False, default=str))

def public_ip_info(ip_text):
    result = {}
    try:
        req = urllib.request.Request(
            "https://ipwho.is/" + urllib.parse.quote(ip_text),
            headers={"User-Agent": "PhantomsEye-CMD/2.3"}
        )
        with urllib.request.urlopen(req, timeout=12) as response:
            result = json.loads(response.read().decode("utf-8", "replace"))
    except Exception as exc:
        result = {"lookup_error": str(exc)}
    return result

def rdap_info(ip_text):
    for base_url in ("https://rdap.org/ip/", "https://rdap.arin.net/registry/ip/"):
        try:
            req = urllib.request.Request(
                base_url + urllib.parse.quote(ip_text),
                headers={"User-Agent": "PhantomsEye-CMD/2.3", "Accept": "application/rdap+json"}
            )
            with urllib.request.urlopen(req, timeout=12) as response:
                return json.loads(response.read().decode("utf-8", "replace"))
        except Exception:
            continue
    return {"lookup_error": "RDAP registry lookup unavailable"}

def resolve(host):
    try:
        return sorted({entry[4][0] for entry in socket.getaddrinfo(host, None)})
    except Exception:
        return []

def ptr_info(ip_text):
    try:
        name, aliases, addresses = socket.gethostbyaddr(ip_text)
        return {"canonical_name": name, "aliases": aliases or [], "addresses": addresses or []}
    except Exception as exc:
        return {"error": str(exc)}

def ip_deep_search():
    header("IP DEEP SEARCH")
    raw = ask("Enter public IP address: ")
    try:
        ip = ipaddress.ip_address(raw)
    except ValueError:
        print("Invalid IP address."); pause(); return
    if not ip.is_global:
        print("Enter a public, globally routable IP address for this lookup."); pause(); return

    print(f"\nTARGET: {ip}")
    rule("=")
    print("[IDENTIFICATION]")
    print(f"Input IP: {ip}")
    print(f"IP Version: IPv{ip.version}")
    print(f"Public / globally routable: {ip.is_global}")
    print(f"Private: {ip.is_private}")
    print(f"Reserved: {ip.is_reserved}")
    print(f"Compressed: {ip.compressed}")

    print("\n[DNS / RESOLUTION]")
    ptr = ptr_info(str(ip))
    print(f"PTR canonical name: {ptr.get('canonical_name', 'unavailable')}")
    print(f"PTR aliases: {', '.join(ptr.get('aliases', [])) or 'none'}")
    print(f"PTR addresses: {', '.join(ptr.get('addresses', [])) or 'none'}")

    print("\n[GEOLOCATION / NETWORK / ASN]")
    geo = public_ip_info(str(ip))
    if geo.get("lookup_error"):
        print("Geolocation lookup error:", geo["lookup_error"])
    else:
        for key in ("success", "type", "continent", "continent_code", "country", "country_code",
                    "region", "region_code", "city", "postal", "latitude", "longitude",
                    "is_eu", "calling_code", "capital", "borders"):
            if key in geo:
                print(f"{key}: {geo[key]}")
        print("CONNECTION:")
        for key, value in (geo.get("connection") or {}).items():
            print(f"  {key}: {value}")
        print("TIMEZONE:")
        for key, value in (geo.get("timezone") or {}).items():
            print(f"  {key}: {value}")
        print("FLAG:")
        for key, value in (geo.get("flag") or {}).items():
            print(f"  {key}: {value}")

    print("\n[RDAP / REGISTRATION]")
    rdap = rdap_info(str(ip))
    if rdap.get("lookup_error"):
        print(rdap["lookup_error"])
    else:
        # Keep the complete registry response available without making the screen unreadable.
        for key in ("name", "handle", "type", "startAddress", "endAddress", "ipVersion",
                    "parentHandle", "status", "country", "port43", "rdapConformance",
                    "cidr0_cidrs", "arin_originas0_originautnums", "events", "links", "notices"):
            if key in rdap:
                print(f"{key}: {json.dumps(rdap[key], indent=2, ensure_ascii=False)}")
        print("\n[RDAP ENTITIES / CONTACTS]")
        for entity in rdap.get("entities", []):
            print(json.dumps(entity, indent=2, ensure_ascii=False))
    print("\n[SOURCES]")
    print("System DNS resolver")
    print("ipwho.is public geolocation / network API")
    print("rdap.org / registry RDAP service")
    print("Geo-IP is approximate; unavailable fields are not invented.")
    pause()

def url_deep_search():
    header("URL DEEP SEARCH")
    raw = ask("Enter URL or domain: ")
    if not raw:
        print("No target supplied."); pause(); return
    url = raw if "://" in raw else "https://" + raw
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        print("Invalid URL. Example: https://example.com"); pause(); return
    host = parsed.hostname
    ips = resolve(host)
    primary = ips[0] if ips else None

    print(f"\nTARGET: {host}")
    rule("=")
    print("[IDENTIFICATION]")
    print(f"Input Hostname: {host}")
    print(f"Resolved IPs: {', '.join(ips) if ips else 'unavailable'}")
    if primary:
        ip_obj = ipaddress.ip_address(primary)
        print(f"Primary IP Version: IPv{ip_obj.version}")
        print(f"Public / globally routable: {ip_obj.is_global}")
        print(f"Private: {ip_obj.is_private}")
        print(f"Reserved: {ip_obj.is_reserved}")
    else:
        print("Primary IP Version: unavailable")
        print("Public / globally routable: unavailable")
        print("Private: unavailable")
        print("Reserved: unavailable")

    print("\n[DNS / RESOLUTION]")
    print(f"A / AAAA via system resolver: {', '.join(ips) if ips else 'unavailable'}")
    if primary:
        ptr = ptr_info(primary)
        print(f"PTR canonical name: {ptr.get('canonical_name', 'unavailable')}")
        print(f"PTR aliases: {', '.join(ptr.get('aliases', [])) or 'none'}")
        print(f"PTR addresses: {', '.join(ptr.get('addresses', [])) or 'none'}")
    else:
        print("PTR data: unavailable (no resolved IP)")

    if primary and ipaddress.ip_address(primary).is_global:
        print("\n[GEOLOCATION / NETWORK / ASN]")
        geo = public_ip_info(primary)
        if geo.get("lookup_error"):
            print("Lookup error:", geo["lookup_error"])
        else:
            for key in ("success", "type", "continent", "continent_code", "country", "country_code",
                        "region", "region_code", "city", "postal", "latitude", "longitude",
                        "is_eu", "calling_code", "capital", "borders"):
                if key in geo:
                    print(f"{key}: {geo[key]}")
            print("CONNECTION:")
            for key, value in (geo.get("connection") or {}).items():
                print(f"  {key}: {value}")
            print("TIMEZONE:")
            for key, value in (geo.get("timezone") or {}).items():
                print(f"  {key}: {value}")
            print("FLAG:")
            for key, value in (geo.get("flag") or {}).items():
                print(f"  {key}: {value}")

        print("\n[RDAP / REGISTRATION]")
        rdap = rdap_info(primary)
        if rdap.get("lookup_error"):
            print(rdap["lookup_error"])
        else:
            # Complete RDAP JSON is included because registry records vary by provider.
            print(json.dumps(rdap, indent=2, ensure_ascii=False))
    else:
        print("\n[GEOLOCATION / NETWORK / ASN]")
        print("Skipped: no public resolved IP was available.")

    print("\n[HTTP / RESPONSE]")
    headers = {}
    final_url = url
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; PhantomsEye-CMD/2.3)"})
        try:
            with urllib.request.urlopen(req, timeout=15) as response:
                status = response.status
                final_url = response.geturl()
                headers = dict(response.headers.items())
                print(f"Status code: {status}")
                print(f"Final URL: {final_url}")
                print(f"Redirected: {final_url != url}")
        except urllib.error.HTTPError as exc:
            headers = dict(exc.headers.items()) if exc.headers else {}
            print(f"Status code: {exc.code}")
            print(f"Final URL: {exc.geturl()}")
            print(f"HTTP error: {exc.reason}")
        for key in ("Content-Type", "Content-Length", "Server", "Last-Modified", "Cache-Control"):
            print(f"{key}: {headers.get(key, 'not disclosed')}")
    except Exception as exc:
        print("HTTP request failed:", exc)

    print("\n[SECURITY HEADERS]")
    for key in ("Strict-Transport-Security", "Content-Security-Policy", "X-Content-Type-Options",
                "X-Frame-Options", "Referrer-Policy", "Permissions-Policy",
                "Cross-Origin-Opener-Policy", "Cross-Origin-Resource-Policy"):
        print(f"{key}: {headers.get(key, '[NOT PRESENT]')}")

    print("\n[TLS]")
    if parsed.scheme == "https":
        try:
            context = ssl.create_default_context()
            with socket.create_connection((host, parsed.port or 443), timeout=8) as sock:
                with context.wrap_socket(sock, server_hostname=host) as tls:
                    cert = tls.getpeercert()
                    print(f"TLS version: {tls.version()}")
                    print(f"Cipher: {tls.cipher()[0] if tls.cipher() else 'unknown'}")
                    print(f"Certificate expires: {cert.get('notAfter', 'not disclosed')}")
                    print(f"Certificate subject: {cert.get('subject', 'not disclosed')}")
        except Exception as exc:
            print("TLS details unavailable:", exc)
    else:
        print("No TLS session: target URL uses HTTP.")

    print("\n[SOURCES]")
    print("System DNS resolver")
    print("ipwho.is public geolocation / network API")
    print("rdap.org / registry RDAP service")
    print("Direct HTTP and TLS connection to the entered URL")
    print("Geo-IP is approximate; missing headers do not automatically mean a vulnerability.")
    pause()

def dns_lookup():
    header("DNS LOOKUP")
    host = ask("Hostname: ")
    for address in resolve(host):
        print("Address:", address)
    pause()

def hash_analyzer():
    header("HASH ANALYZER")
    path = input("Path to local file: ").strip().strip('"')
    try:
        with open(path, "rb") as f: data = f.read()
        print("File size:", len(data), "bytes")
        for alg in ("sha256", "sha1", "md5"):
            print(f"{alg.upper():<8}: {hashlib.new(alg, data).hexdigest()}")
    except Exception as exc: print("Could not read file:", exc)
    pause()

def base64_tool():
    header("BASE64 / TEXT")
    mode = ask("1 Encode / 2 Decode: ")
    value = input("Text: ")
    try:
        result = base64.b64encode(value.encode()).decode() if mode == "1" else base64.b64decode(value, validate=True).decode("utf-8")
        print("\nResult:\n" + result)
    except Exception as exc: print("Conversion failed:", exc)
    pause()

def json_inspector():
    header("JSON INSPECTOR")
    print("Paste JSON; finish with a line containing END.")
    lines = []
    while True:
        line_text = input()
        if line_text.strip() == "END": break
        lines.append(line_text)
    try: print(json.dumps(json.loads("\n".join(lines)), indent=2, ensure_ascii=False))
    except Exception as exc: print("Invalid JSON:", exc)
    pause()

def log_analyzer():
    header("LOG ANALYZER")
    path = ask("Path to log file (blank to paste): ").strip('"')
    if path:
        try:
            with open(path, encoding="utf-8", errors="replace") as f: data = f.read()
        except Exception as exc: print("Could not read file:", exc); pause(); return
    else:
        print("Paste log; finish with END.")
        lines = []
        while True:
            s = input()
            if s.strip() == "END": break
            lines.append(s)
        data = "\n".join(lines)
    terms = ("error", "failed", "warning", "denied", "unauthorized", "timeout", "critical", "exception")
    hits = [(i, s) for i, s in enumerate(data.splitlines(), 1) if any(t in s.lower() for t in terms)]
    print(f"\nIndicators found: {len(hits)}")
    for i, s in hits: print(f"{i}: {s}")
    pause()

def email_headers():
    header("EMAIL HEADER CHECK")
    print("Paste headers; finish with END.")
    lines = []
    while True:
        s = input()
        if s.strip() == "END": break
        lines.append(s)
    raw = "\n".join(lines)
    for field in ("From", "To", "Date", "Subject", "Message-ID", "Return-Path", "Reply-To", "Authentication-Results"):
        match = re.search(r"(?im)^" + re.escape(field) + r":\s*(.+(?:\n[ \t].+)*)", raw)
        print(f"{field:<24}: {match.group(1).replace(chr(10), ' ') if match else 'not present'}")
    print("Header fields are clues, not proof of sender identity.")
    pause()

def localhost_ports():
    header("LOCALHOST PORT CHECK")
    print("Restricted to 127.0.0.1 only.")
    raw = ask("Ports (comma-separated, e.g. 22,80,443): ")
    try: ports = sorted({int(x.strip()) for x in raw.split(",") if x.strip()})
    except ValueError: print("Invalid port list."); pause(); return
    if any(p < 1 or p > 65535 for p in ports):
        print("Ports must be between 1 and 65535."); pause(); return
    for port in ports:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=.4): print(f"{port:5} OPEN")
        except OSError: print(f"{port:5} closed / not responding")
    pause()

def about():
    header("ABOUT / HELP")
    print("Passive public metadata, DNS, HTTP/TLS checks and local defensive utilities.")
    print("Long results remain in terminal scrollback; use mouse wheel / scrollbar.")
    print("No malware execution, credential theft, flooding, or remote port scanning.")
    pause()

FUNCTIONS = {1: ip_deep_search, 2: url_deep_search, 3: dns_lookup, 4: hash_analyzer,
             5: base64_tool, 6: json_inspector, 7: log_analyzer, 8: email_headers,
             9: localhost_ports, 10: about}

def show_menu():
    clear()
    print(PURPLE + BOLD + "PHANTOMS EYE // CMD EDITION v2.3" + RESET)
    print(DIM + "PASSIVE INTELLIGENCE / DEFENSIVE ANALYSIS" + RESET)
    rule("=")
    print(PURPLE + EYE + RESET)
    print("MODULES  (enter 1-10)")
    for n, (name, desc) in enumerate(TOOLS, 1):
        print(f" {PURPLE}{n:02}{RESET}  {WHITE}{name:<23}{RESET} {DIM}{desc}{RESET}")
    rule("-")
    print(f"{BLUE}STATUS:{RESET} READY   {BLUE}MODE:{RESET} PASSIVE ONLY")
    print(DIM + "Use terminal scrollback for long reports. Q to quit." + RESET)

def main():
    if os.name == "nt":
        os.system("")
    while True:
        try:
            show_menu()
            choice = input(f"\n{PURPLE}PHANTOMS EYE > {RESET}").strip().lower()
            if choice in ("q", "quit", "exit"):
                clear()
                print(PURPLE + "PHANTOMS EYE // session closed" + RESET)
                break
            if not choice.isdigit() or int(choice) not in FUNCTIONS:
                input("Enter 1-10. Press Enter...")
                continue
            FUNCTIONS[int(choice)]()
        except KeyboardInterrupt:
            print("\nInterrupted."); input("Press Enter to return...")
        except EOFError:
            break

if __name__ == "__main__":
    main()
